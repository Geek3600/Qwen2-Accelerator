package DM

object Param {
    val BATCHSIZE = 32
    val SINGLE_QUERY_BATCH = 12
    val LBANCHNUM = 4
    val LBATCHSIZE = BATCHSIZE * LBANCHNUM // 加速器可以同时为128个用户维护独立的历史KVcache
    val LOAD_VECNUM = 2 // 每周期从Load0收到2个Q元素+2个K元素
    val HEAD_VECNUM = 64 // 一个Q/K向量有64个元素
    // 912 只作为 attention runtime 历史长度上限存在，供 token-by-token wrapper 调度使用。
    // core 内部的固定阵列与本地 tile/pre-fill 缓冲仍保持原始 26 口径。
    val MAX_SEQLEN = 912
    val MAX_PREFILL = 912
    val TILE_SEQLEN = 26
    val LOCAL_PREFILL = 26
    val MULNUM = 32 //32个乘法器
    val DATAW = 8 // 数据位宽
    val MEM_DEPTH = 512

}
