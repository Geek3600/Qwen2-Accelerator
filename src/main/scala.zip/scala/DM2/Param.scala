package DM2

object Param {
  val BATCHSIZE = 32 // decode阶段下的batch size
  val SINGLE_QUERY_BATCH = 12
  val LBANCHNUM = 4
  val LBATCHSIZE = BATCHSIZE * LBANCHNUM
  val HEAD_VECNUM = 64 // 每个注意力头的维度
  // 运行时支持的最大历史长度。912 的长序列支持必须通过调度/循环完成，
  // 不能再把核心阵列和片上缓存按 912 线性展开。
  val MAX_SEQLEN = 912
  val MAX_PREFILL = 912
  // 核心 attention 计算/片上 tile 的固定规模，恢复到前期 26 序列口径。
  val TILE_SEQLEN = 26
  val MULNUM = 32 //乘法器数量
  val DATAW = 8 // 数据位宽
  val MEM_DEPTH = BATCHSIZE
}


